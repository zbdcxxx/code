package com.suyuan;

import com.intellij.openapi.fileChooser.FileChooser;
import com.intellij.openapi.fileChooser.FileChooserDescriptor;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.DialogWrapper;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.List;
import java.util.Map;

/**
 * Flyway SQL版本分析结果对话框
 * 显示分析结果并提供一键修复按钮
 * 
 * @author zhangx
 */
public class FlywayAnalysisResultDialog extends DialogWrapper {
    
    /** 结果文本区域 */
    private JTextArea resultTextArea;
    
    /** 一键修复按钮 */
    private JButton repairButton;
    
    /** 配置文件路径输入框 */
    private JTextField configFilePathField;
    
    /** Flyway历史表名输入框 */
    private JTextField flywayTableNameField;
    
    /** 数据库URL显示标签 */
    private JLabel dbUrlLabel;
    
    /** 项目引用 */
    private final Project project;
    
    /** 项目路径 */
    private final String projectPath;
    
    /** 分析结果消息 */
    private final String resultMessage;
    
    /** Flyway locations配置 */
    private final List<String> flywayLocations;
    
    /** 当前分支的SQL文件集合 */
    private final java.util.Set<String> currentBranchSqlFiles;
    
    /** 各分支SQL文件映射 */
    private final Map<String, java.util.Set<String>> branchSqlFiles;
    
    /** 是否找到了SQL文件 */
    private final boolean hasSqlFiles;
    
    /** 自动检测到的配置文件路径 */
    private String detectedConfigFilePath;
    
    /** 自动检测到的Flyway表名 */
    private String detectedFlywayTableName;

    /**
     * 构造函数
     * 
     * @param project 当前项目
     * @param projectPath 项目路径
     * @param resultMessage 分析结果消息
     * @param flywayLocations Flyway locations配置
     * @param currentBranchSqlFiles 当前分支的SQL文件
     * @param branchSqlFiles 各分支SQL文件映射
     * @param hasSqlFiles 是否找到SQL文件
     */
    public FlywayAnalysisResultDialog(@Nullable Project project,
                                       String projectPath,
                                       String resultMessage,
                                       List<String> flywayLocations,
                                       java.util.Set<String> currentBranchSqlFiles,
                                       Map<String, java.util.Set<String>> branchSqlFiles,
                                       boolean hasSqlFiles) {
        super(project);
        this.project = project;
        this.projectPath = projectPath;
        this.resultMessage = resultMessage;
        this.flywayLocations = flywayLocations;
        this.currentBranchSqlFiles = currentBranchSqlFiles;
        this.branchSqlFiles = branchSqlFiles;
        this.hasSqlFiles = hasSqlFiles;
        
        // 自动检测配置文件路径
        this.detectedConfigFilePath = FlywayRepairService.detectConfigFilePath(projectPath);
        
        // 预读取数据库配置获取默认表名
        if (this.detectedConfigFilePath != null) {
            FlywayRepairService.DatabaseConfigPreview preview = 
                FlywayRepairService.previewDatabaseConfig(this.detectedConfigFilePath);
            if (preview != null && preview.defaultFlywayTableName != null) {
                this.detectedFlywayTableName = preview.defaultFlywayTableName;
            }
        }
        
        setTitle("Flyway一键修复");
        setModal(false); // 非模态对话框，允许后台操作
        init();
    }

    @Override
    protected @Nullable JComponent createCenterPanel() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // 配置面板（顶部）
        JPanel configPanel = createConfigPanel();
        mainPanel.add(configPanel, BorderLayout.NORTH);
        
        // 结果文本区域
        resultTextArea = new JTextArea(resultMessage);
        resultTextArea.setEditable(false);
        resultTextArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        resultTextArea.setLineWrap(true);
        resultTextArea.setWrapStyleWord(true);
        
        JScrollPane scrollPane = new JScrollPane(resultTextArea);
        scrollPane.setPreferredSize(new Dimension(700, 350));
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        return mainPanel;
    }
    
    /**
     * 创建配置面板
     */
    private JPanel createConfigPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("修复配置"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // 第一行：配置文件路径
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        panel.add(new JLabel("配置文件:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        configFilePathField = new JTextField(detectedConfigFilePath != null ? detectedConfigFilePath : "");
        configFilePathField.setEditable(false);
        configFilePathField.setPreferredSize(new Dimension(400, 28));
        panel.add(configFilePathField, gbc);
        
        gbc.gridx = 2;
        gbc.weightx = 0;
        JButton browseButton = new JButton("浏览...");
        browseButton.addActionListener(e -> browseConfigFile());
        panel.add(browseButton, gbc);
        
        // 第二行：数据库URL（只读显示）
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        panel.add(new JLabel("数据库URL:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        dbUrlLabel = new JLabel(getDbUrlFromConfig());
        dbUrlLabel.setForeground(Color.GRAY);
        panel.add(dbUrlLabel, gbc);
        
        // 第三行：Flyway历史表名
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.weightx = 0;
        panel.add(new JLabel("Flyway表名:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        flywayTableNameField = new JTextField(detectedFlywayTableName != null ? detectedFlywayTableName : "flyway_schema_history");
        flywayTableNameField.setPreferredSize(new Dimension(400, 28));
        panel.add(flywayTableNameField, gbc);
        
        // 提示信息
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 3;
        JLabel tipLabel = new JLabel("提示: 如自动检测的配置不正确，请手动选择配置文件或修改表名");
        tipLabel.setFont(tipLabel.getFont().deriveFont(Font.ITALIC, 11f));
        tipLabel.setForeground(Color.GRAY);
        panel.add(tipLabel, gbc);
        
        return panel;
    }
    
    /**
     * 从配置中获取数据库URL
     */
    private String getDbUrlFromConfig() {
        if (detectedConfigFilePath != null) {
            FlywayRepairService.DatabaseConfigPreview preview = 
                FlywayRepairService.previewDatabaseConfig(detectedConfigFilePath);
            if (preview != null && preview.url != null) {
                return preview.url;
            }
        }
        return "未检测到";
    }
    
    /**
     * 浏览选择配置文件
     */
    private void browseConfigFile() {
        FileChooserDescriptor descriptor = new FileChooserDescriptor(true, false, false, false, false, false)
                .withTitle("选择配置文件")
                .withDescription("请选择application.yml或application.yaml配置文件")
                .withFileFilter(file -> {
                    String name = file.getName().toLowerCase();
                    return name.endsWith(".yml") || name.endsWith(".yaml");
                });
        
        // 设置默认路径
        VirtualFile initialDir = null;
        if (projectPath != null) {
            initialDir = LocalFileSystem.getInstance().findFileByPath(projectPath);
        }
        
        VirtualFile selectedFile = FileChooser.chooseFile(descriptor, project, initialDir);
        if (selectedFile != null) {
            String newPath = selectedFile.getPath();
            configFilePathField.setText(newPath);
            
            // 更新数据库URL和表名
            FlywayRepairService.DatabaseConfigPreview preview = 
                FlywayRepairService.previewDatabaseConfig(newPath);
            if (preview != null) {
                if (preview.url != null) {
                    dbUrlLabel.setText(preview.url);
                }
                if (preview.defaultFlywayTableName != null) {
                    flywayTableNameField.setText(preview.defaultFlywayTableName);
                }
            } else {
                dbUrlLabel.setText("无法解析配置文件");
            }
        }
    }

    @Override
    protected Action @NotNull [] createActions() {
        // 创建开始修复按钮
        Action repairAction = new DialogWrapperAction("开始修复") {
            @Override
            protected void doAction(java.awt.event.ActionEvent e) {
                performRepair();
            }
        };
        
        // 创建关闭按钮
        Action closeAction = getOKAction();
        closeAction.putValue(Action.NAME, "关闭");
        
        // 只有在启用修复功能时才显示修复按钮
        if (!hasSqlFiles) {
            repairAction.setEnabled(false);
        }
        
        return new Action[]{repairAction, closeAction};
    }

    /**
     * 执行一键修复操作
     */
    private void performRepair() {
        // 获取用户确认的配置
        String configFilePath = configFilePathField.getText().trim();
        String flywayTableName = flywayTableNameField.getText().trim();
        
        // 验证配置
        if (configFilePath.isEmpty()) {
            appendLog("\n❌ 错误: 请选择配置文件!");
            return;
        }
        if (!new File(configFilePath).exists()) {
            appendLog("\n❌ 错误: 配置文件不存在: " + configFilePath);
            return;
        }
        if (flywayTableName.isEmpty()) {
            appendLog("\n❌ 错误: 请输入Flyway历史表名!");
            return;
        }
        
        // 创建修复服务
        FlywayRepairService repairService = new FlywayRepairService(
                project, 
                projectPath, 
                flywayLocations,
                currentBranchSqlFiles
        );
        
        // 设置用户确认的配置
        repairService.setConfigFilePath(configFilePath);
        repairService.setCustomFlywayTableName(flywayTableName);
        
        // 追加日志到结果区域
        appendLog("\n\n═══════════════════════════════════════════");
        appendLog("【开始执行一键修复】");
        appendLog("═══════════════════════════════════════════\n");
        appendLog("【修复参数】");
        appendLog("  配置文件: " + configFilePath);
        appendLog("  Flyway表名: " + flywayTableName);
        appendLog("");
        
        // 执行修复（在后台线程）
        repairService.executeRepair(this::appendLog, this::onRepairComplete);
    }

    /**
     * 追加日志到结果区域
     * 
     * @param log 日志内容
     */
    public void appendLog(String log) {
        SwingUtilities.invokeLater(() -> {
            resultTextArea.append(log + "\n");
            // 滚动到底部
            resultTextArea.setCaretPosition(resultTextArea.getDocument().getLength());
        });
    }

    /**
     * 修复完成回调
     * 
     * @param success 是否成功
     * @param message 完成消息
     */
    private void onRepairComplete(boolean success, String message) {
        SwingUtilities.invokeLater(() -> {
            appendLog("\n" + message);
            if (success) {
                appendLog("\n【修复完成】所有问题已处理完毕！");
            } else {
                appendLog("\n【修复异常】" + message);
            }
        });
    }
}
