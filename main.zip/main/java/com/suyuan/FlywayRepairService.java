package com.suyuan;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.progress.Task;
import com.intellij.openapi.project.Project;
import org.jetbrains.annotations.NotNull;
import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.SafeConstructor;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.sql.*;
import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.zip.CRC32;

/**
 * Flyway版本历史修复服务
 * 负责检测和修复Flyway版本历史记录表的各种问题
 * 
 * @author zhangx
 */
public class FlywayRepairService {

    /** Flyway SQL文件名匹配模式 */
    private static final Pattern FLYWAY_VERSION_PATTERN = Pattern.compile(
            "^[VvUuRr]([0-9]+(?:[._][0-9]+)*)__.*\\.sql$"
    );

    /** 项目引用 */
    private final Project project;

    /** 项目路径 */
    private final String projectPath;

    /** Flyway locations配置 */
    private final List<String> flywayLocations;

    /** 当前分支SQL文件集合 */
    private final Set<String> currentBranchSqlFiles;

    /** 指定的配置文件路径（可为null，表示自动检测） */
    private String configFilePath;

    /** 指定的Flyway历史表名（可为null，表示自动生成） */
    private String customFlywayTableName;

    /**
     * 数据库配置信息
     */
    private static class DatabaseConfig {
        String url;
        String username;
        String password;
        String databaseName;
        String projectIdentifier;  // 项目标识
        String flywayTableName;    // Flyway历史表名

        @Override
        public String toString() {
            return String.format("DatabaseConfig{url='%s', username='%s', database='%s', identifier='%s', table='%s'}",
                    url, username, databaseName, projectIdentifier, flywayTableName);
        }
    }

    /**
     * Flyway历史记录
     */
    private static class FlywayHistoryRecord {
        int installedRank;
        String version;
        String description;
        String type;
        String script;
        Integer checksum;
        String installedBy;
        Timestamp installedOn;
        int executionTime;
        boolean success;

        @Override
        public String toString() {
            return String.format("V%s__%s (rank=%d, checksum=%d, success=%s)",
                    version, description, installedRank, checksum, success);
        }
    }

    /**
     * 构造函数
     */
    public FlywayRepairService(Project project, String projectPath,
                                List<String> flywayLocations,
                                Set<String> currentBranchSqlFiles) {
        this.project = project;
        this.projectPath = projectPath;
        this.flywayLocations = flywayLocations;
        this.currentBranchSqlFiles = currentBranchSqlFiles;
    }

    /**
     * 设置配置文件路径
     * @param configFilePath 配置文件绝对路径
     */
    public void setConfigFilePath(String configFilePath) {
        this.configFilePath = configFilePath;
    }

    /**
     * 设置自定义Flyway历史表名
     * @param tableName Flyway历史表名
     */
    public void setCustomFlywayTableName(String tableName) {
        this.customFlywayTableName = tableName;
    }

    /**
     * 执行修复操作（后台线程）
     * 
     * @param logCallback 日志回调
     * @param completeCallback 完成回调 (success, message)
     */
    public void executeRepair(Consumer<String> logCallback, BiConsumer<Boolean, String> completeCallback) {
        ProgressManager.getInstance().run(new Task.Backgroundable(project, "Flyway一键修复", true) {
            @Override
            public void run(@NotNull ProgressIndicator indicator) {
                try {
                    // Step 1: 读取数据库配置
                    indicator.setText("正在读取数据库配置...");
                    indicator.setFraction(0.1);
                    logCallback.accept("【Step 1】读取数据库配置...");

                    DatabaseConfig dbConfig = readDatabaseConfig();
                    if (dbConfig == null) {
                        completeCallback.accept(false, "无法读取数据库配置，请检查application.yml文件");
                        return;
                    }
                    logCallback.accept("  数据库URL: " + dbConfig.url);
                    logCallback.accept("  数据库名: " + dbConfig.databaseName);
                    logCallback.accept("  项目标识: " + dbConfig.projectIdentifier);
                    logCallback.accept("  Flyway表名: " + dbConfig.flywayTableName);

                    // Step 2: 获取本地SQL文件列表
                    indicator.setText("正在获取本地SQL文件...");
                    indicator.setFraction(0.15);
                    logCallback.accept("\n【Step 2】获取本地SQL文件...");

                    Map<String, File> localSqlFiles = getLocalSqlFiles();
                    if (localSqlFiles.isEmpty()) {
                        completeCallback.accept(false, "未找到本地SQL文件");
                        return;
                    }
                    logCallback.accept("  找到 " + localSqlFiles.size() + " 个SQL文件");

                    // Step 2.1: 检查是否存在版本号重复的SQL文件
                    indicator.setText("正在检查版本号重复...");
                    indicator.setFraction(0.2);
                    logCallback.accept("\n【Step 2.1】检查版本号重复的SQL文件...");

                    Map<String, List<String>> duplicateVersions = FlywayRepairService.this.checkDuplicateVersions(localSqlFiles.keySet());
                    if (!duplicateVersions.isEmpty()) {
                        logCallback.accept("  ❌ 发现版本号重复的SQL文件:");
                        for (Map.Entry<String, List<String>> entry : duplicateVersions.entrySet()) {
                            logCallback.accept("    版本 " + entry.getKey() + ":");
                            for (String file : entry.getValue()) {
                                logCallback.accept("      • " + file);
                            }
                        }
                        logCallback.accept("\n  ⚠️ 请先处理版本号重复的SQL文件，确保每个版本号只有一个SQL文件后再执行修复！");
                        completeCallback.accept(false, "检测到版本号重复的SQL文件，修复操作已取消。请先处理重复版本后再执行修复。");
                        return;
                    }
                    logCallback.accept("  ✓ 未发现版本号重复的SQL文件");

                    // 按版本号排序的SQL文件列表
                    List<String> sortedSqlFiles = localSqlFiles.keySet().stream()
                            .sorted(FlywayRepairService.this::compareFlywayVersion)
                            .collect(Collectors.toList());

                    for (String file : sortedSqlFiles) {
                        logCallback.accept("    • " + file);
                    }

                    // Step 3: 连接数据库并获取历史记录
                    indicator.setText("正在连接数据库...");
                    indicator.setFraction(0.3);
                    logCallback.accept("\n【Step 3】连接数据库并获取历史记录...");

                    try (Connection conn = getConnection(dbConfig)) {
                        logCallback.accept("  数据库连接成功");

                        // 检查Flyway历史表是否存在
                        if (!tableExists(conn, dbConfig.flywayTableName)) {
                            logCallback.accept("  ❌ Flyway历史表不存在: " + dbConfig.flywayTableName);
                            logCallback.accept("  请先确保数据库中存在该表，或检查表名配置是否正确");
                            completeCallback.accept(false, "Flyway历史表 '" + dbConfig.flywayTableName + "' 在数据库中不存在，修复操作已取消");
                            return;
                        }

                        // 获取现有历史记录
                        List<FlywayHistoryRecord> historyRecords = getFlywayHistory(conn, dbConfig.flywayTableName);
                        logCallback.accept("  现有历史记录: " + historyRecords.size() + " 条");

                        // Step 4: 检测并修复问题
                        indicator.setText("正在检测问题...");
                        indicator.setFraction(0.4);
                        logCallback.accept("\n【Step 4】检测并修复问题...");

                        // 构建已执行记录的映射 (script -> record)
                        Map<String, FlywayHistoryRecord> executedScripts = new HashMap<>();
                        for (FlywayHistoryRecord record : historyRecords) {
                            executedScripts.put(record.script, record);
                        }

                        int fixedCount = 0;
                        int errorCount = 0;

                        // 4.1 检查并删除数据库中存在但本地不存在的记录
                        logCallback.accept("\n  ▶ 检查数据库中多余的记录(本地不存在的SQL)...");
                        List<FlywayHistoryRecord> obsoleteRecords = new ArrayList<>();
                        for (FlywayHistoryRecord record : historyRecords) {
                            // 跳过非迁移类型的记录(如 BASELINE 等)
                            if (!"SQL".equals(record.type) && !"UNDO_SQL".equals(record.type) && !"SQL_REPEATABLE".equals(record.type)) {
                                continue;
                            }
                            if (!localSqlFiles.containsKey(record.script)) {
                                obsoleteRecords.add(record);
                            }
                        }

                        if (!obsoleteRecords.isEmpty()) {
                            logCallback.accept("    ⚠️ 发现 " + obsoleteRecords.size() + " 条数据库中存在但本地SQL目录不存在的记录:");
                            for (FlywayHistoryRecord record : obsoleteRecords) {
                                logCallback.accept("      • " + record.script + " (version: " + record.version + ")");
                            }
                            logCallback.accept("    正在删除这些多余记录...");
                            for (FlywayHistoryRecord record : obsoleteRecords) {
                                try {
                                    deleteHistoryRecord(conn, dbConfig.flywayTableName, record.installedRank);
                                    logCallback.accept("      ✓ 已删除: " + record.script);
                                    fixedCount++;
                                    // 从 executedScripts 中移除已删除的记录
                                    executedScripts.remove(record.script);
                                } catch (SQLException e) {
                                    logCallback.accept("      ✗ 删除失败: " + record.script + " - " + e.getMessage());
                                    errorCount++;
                                }
                            }
                            // 从 historyRecords 中移除已删除的记录
                            historyRecords.removeAll(obsoleteRecords);
                        } else {
                            logCallback.accept("    ✓ 无多余记录");
                        }

                        // 4.2 检查success=0的记录并修复
                        logCallback.accept("\n  ▶ 检查执行失败的记录 (success=0)...");
                        for (FlywayHistoryRecord record : historyRecords) {
                            if (!record.success) {
                                logCallback.accept("    发现失败记录: " + record.script);
                                try {
                                    updateSuccessStatus(conn, dbConfig.flywayTableName, record.installedRank, true);
                                    logCallback.accept("    ✓ 已修复: success -> 1");
                                    fixedCount++;
                                } catch (SQLException e) {
                                    logCallback.accept("    ✗ 修复失败: " + e.getMessage());
                                    errorCount++;
                                }
                            }
                        }

                        // 4.3 检查checksum不匹配的问题
                        logCallback.accept("\n  ▶ 检查checksum不匹配...");
                        for (Map.Entry<String, File> entry : localSqlFiles.entrySet()) {
                            String fileName = entry.getKey();
                            File sqlFile = entry.getValue();

                            FlywayHistoryRecord record = executedScripts.get(fileName);
                            if (record != null && record.checksum != null) {
                                // 计算当前文件的checksum
                                int currentChecksum = calculateFlywayChecksum(sqlFile);
                                if (currentChecksum != record.checksum) {
                                    logCallback.accept("    发现checksum不匹配: " + fileName);
                                    logCallback.accept("      数据库checksum: " + record.checksum);
                                    logCallback.accept("      本地计算checksum: " + currentChecksum);
                                    
                                    try {
                                        updateChecksum(conn, dbConfig.flywayTableName, record.installedRank, currentChecksum);
                                        logCallback.accept("    ✓ 已将数据库checksum更新为: " + currentChecksum);
                                        fixedCount++;
                                    } catch (SQLException e) {
                                        logCallback.accept("    ✗ 更新失败: " + e.getMessage());
                                        errorCount++;
                                    }
                                }
                            }
                        }

                        // 4.4 检查缺失的SQL文件记录
                        logCallback.accept("\n  ▶ 检查缺失的SQL执行记录...");
                        List<String> missingSqlFiles = new ArrayList<>();
                        for (String sqlFile : sortedSqlFiles) {
                            if (!executedScripts.containsKey(sqlFile)) {
                                missingSqlFiles.add(sqlFile);
                            }
                        }

                        if (!missingSqlFiles.isEmpty()) {
                            logCallback.accept("    发现 " + missingSqlFiles.size() + " 个缺失的SQL文件:");
                            for (String f : missingSqlFiles) {
                                logCallback.accept("      • " + f);
                            }

                            // 找到第一个缺失SQL的位置，删除之后所有记录
                            String firstMissing = missingSqlFiles.get(0);
                            int firstMissingIndex = sortedSqlFiles.indexOf(firstMissing);

                            // 检查是否需要删除之后的记录
                            List<FlywayHistoryRecord> recordsToDelete = new ArrayList<>();
                            for (FlywayHistoryRecord record : historyRecords) {
                                int recordIndex = sortedSqlFiles.indexOf(record.script);
                                if (recordIndex >= firstMissingIndex) {
                                    recordsToDelete.add(record);
                                }
                            }

                            if (!recordsToDelete.isEmpty()) {
                                logCallback.accept("\n    需要删除 " + recordsToDelete.size() + " 条后续记录以重新执行:");
                                for (FlywayHistoryRecord r : recordsToDelete) {
                                    logCallback.accept("      • " + r.script);
                                    try {
                                        deleteHistoryRecord(conn, dbConfig.flywayTableName, r.installedRank);
                                        logCallback.accept("        ✓ 已删除");
                                    } catch (SQLException e) {
                                        logCallback.accept("        ✗ 删除失败: " + e.getMessage());
                                        errorCount++;
                                    }
                                }
                            }

                            // 从第一个缺失的SQL开始执行所有后续SQL
                            logCallback.accept("\n    开始执行缺失的SQL文件...");
                            indicator.setFraction(0.5);

                            // 获取当前最大的installed_rank
                            int maxRank = getMaxInstalledRank(conn, dbConfig.flywayTableName);

                            List<String> sqlsToExecute = sortedSqlFiles.subList(firstMissingIndex, sortedSqlFiles.size());
                            int total = sqlsToExecute.size();
                            int current = 0;

                            for (String sqlFileName : sqlsToExecute) {
                                current++;
                                indicator.setText2("执行: " + sqlFileName);
                                indicator.setFraction(0.5 + 0.4 * current / total);

                                File sqlFile = localSqlFiles.get(sqlFileName);
                                logCallback.accept("\n    执行 [" + current + "/" + total + "]: " + sqlFileName);

                                maxRank++;
                                boolean executeSuccess = true;
                                String errorMsg = null;
                                long startTime = System.currentTimeMillis();

                                try {
                                    // 执行SQL文件
                                    executeSqlFile(conn, sqlFile);
                                    logCallback.accept("      ✓ SQL执行成功");
                                } catch (SQLException e) {
                                    executeSuccess = false;
                                    errorMsg = e.getMessage();
                                    logCallback.accept("      ✗ SQL执行失败: " + errorMsg);
                                    errorCount++;
                                }

                                long executionTime = System.currentTimeMillis() - startTime;

                                // 无论成功与否，都插入历史记录（失败时success=1以避免再次报错）
                                try {
                                    int checksum = calculateFlywayChecksum(sqlFile);
                                    String version = extractVersionFromFileName(sqlFileName);
                                    String description = extractDescriptionFromFileName(sqlFileName);
                                    String type = extractTypeFromFileName(sqlFileName);

                                    insertHistoryRecord(conn, dbConfig.flywayTableName, maxRank,
                                            version, description, type, sqlFileName, checksum,
                                            dbConfig.username, (int) executionTime, true); // success始终为1

                                    logCallback.accept("      ✓ 历史记录已插入");
                                    fixedCount++;
                                } catch (SQLException e) {
                                    logCallback.accept("      ✗ 插入历史记录失败: " + e.getMessage());
                                    errorCount++;
                                }
                            }
                        } else {
                            logCallback.accept("    所有SQL文件都已有执行记录，无需补充");
                        }

                        // 4.5 最终检查：确保所有记录的success都为1
                        logCallback.accept("\n  ▶ 最终检查并修复剩余的success=0记录...");
                        String finalCheckSql = "UPDATE `" + dbConfig.flywayTableName + "` SET success = 1 WHERE success = 0";
                        try (Statement stmt = conn.createStatement()) {
                            int updated = stmt.executeUpdate(finalCheckSql);
                            if (updated > 0) {
                                logCallback.accept("    ✓ 修复了 " + updated + " 条剩余的success=0记录");
                                fixedCount += updated;
                            } else {
                                logCallback.accept("    无剩余的success=0记录");
                            }
                        } catch (SQLException e) {
                            logCallback.accept("    ✗ 最终修复失败: " + e.getMessage());
                            errorCount++;
                        }

                        // 完成
                        indicator.setFraction(1.0);
                        logCallback.accept("\n═══════════════════════════════════════════");
                        logCallback.accept("【修复统计】");
                        logCallback.accept("  修复成功: " + fixedCount + " 项");
                        logCallback.accept("  修复失败: " + errorCount + " 项");

                        if (errorCount == 0) {
                            completeCallback.accept(true, "修复完成，共处理 " + fixedCount + " 项");
                        } else {
                            completeCallback.accept(false, "修复完成，但有 " + errorCount + " 项失败");
                        }

                    }
                } catch (Exception ex) {
                    logCallback.accept("\n【错误】" + ex.getMessage());
                    ex.printStackTrace();
                    completeCallback.accept(false, "修复过程发生异常: " + ex.getMessage());
                }
            }
        });
    }

    /**
     * 从application.yml读取数据库配置
     */
    private DatabaseConfig readDatabaseConfig() {
        // 如果指定了配置文件路径，优先使用
        if (configFilePath != null && !configFilePath.isEmpty()) {
            File yamlFile = new File(configFilePath);
            if (yamlFile.exists()) {
                DatabaseConfig config = parseDbConfigFromYaml(yamlFile);
                if (config != null) {
                    // 如果指定了自定义表名，使用自定义表名
                    if (customFlywayTableName != null && !customFlywayTableName.isEmpty()) {
                        config.flywayTableName = customFlywayTableName;
                    }
                    return config;
                }
            }
        }

        // 自动检测配置文件
        String[] configFiles = {
                "application.yml",
                "application.yaml",
                "application-dev.yml",
                "application-dev.yaml",
                "application-local.yml"
        };

        for (String configFile : configFiles) {
            File yamlFile = new File(projectPath, configFile);
            if (yamlFile.exists()) {
                DatabaseConfig config = parseDbConfigFromYaml(yamlFile);
                if (config != null) {
                    // 如果指定了自定义表名，使用自定义表名
                    if (customFlywayTableName != null && !customFlywayTableName.isEmpty()) {
                        config.flywayTableName = customFlywayTableName;
                    }
                    return config;
                }
            }
        }

        return null;
    }

    /**
     * 自动检测配置文件路径
     * @param projectPath 项目路径
     * @return 检测到的配置文件路径，未找到返回null
     */
    public static String detectConfigFilePath(String projectPath) {
        String[] configFiles = {
                "application.yml",
                "application.yaml",
                "application-dev.yml",
                "application-dev.yaml",
                "application-local.yml"
        };

        for (String configFile : configFiles) {
            File yamlFile = new File(projectPath, configFile);
            if (yamlFile.exists()) {
                return yamlFile.getAbsolutePath();
            }
        }
        return null;
    }

    /**
     * 从配置文件中预读取数据库配置（用于界面预览）
     * @param configFilePath 配置文件路径
     * @return 数据库配置信息，失败返回null
     */
    public static DatabaseConfigPreview previewDatabaseConfig(String configFilePath) {
        if (configFilePath == null || configFilePath.isEmpty()) {
            return null;
        }
        File yamlFile = new File(configFilePath);
        if (!yamlFile.exists()) {
            return null;
        }

        try (FileInputStream fis = new FileInputStream(yamlFile)) {
            LoaderOptions loaderOptions = new LoaderOptions();
            loaderOptions.setMaxAliasesForCollections(50);
            loaderOptions.setAllowDuplicateKeys(false);

            Yaml yaml = new Yaml(new SafeConstructor(loaderOptions));
            Object yamlData = yaml.load(fis);

            if (yamlData instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> data = (Map<String, Object>) yamlData;

                // 尝试获取 spring.datasource
                Object datasource = getNestedValueStatic(data, "spring", "datasource");
                if (datasource == null) {
                    datasource = getNestedValueStatic(data, "datasource");
                }

                if (datasource instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> dsMap = (Map<String, Object>) datasource;

                    DatabaseConfigPreview preview = new DatabaseConfigPreview();
                    preview.url = getStringValueStatic(dsMap, "url");
                    preview.username = getStringValueStatic(dsMap, "username");

                    if (preview.url != null) {
                        // 从URL中提取数据库名
                        preview.databaseName = extractDatabaseNameStatic(preview.url);
                        if (preview.databaseName != null) {
                            // 计算项目标识和默认表名
                            String projectIdentifier = extractProjectIdentifierStatic(preview.databaseName);
                            preview.defaultFlywayTableName = "flyway_schema_history_" + projectIdentifier;
                        }
                    }
                    return preview;
                }
            }
        } catch (Exception ex) {
            System.err.println("预读取配置文件失败: " + ex.getMessage());
        }
        return null;
    }

    /**
     * 数据库配置预览信息（用于界面显示）
     */
    public static class DatabaseConfigPreview {
        public String url;
        public String username;
        public String databaseName;
        public String defaultFlywayTableName;
    }

    @SuppressWarnings("unchecked")
    private static Object getNestedValueStatic(Map<String, Object> map, String... keys) {
        Object current = map;
        for (String key : keys) {
            if (current instanceof Map) {
                current = ((Map<String, Object>) current).get(key);
            } else {
                return null;
            }
        }
        return current;
    }

    private static String getStringValueStatic(Map<String, Object> map, String key) {
        Object value = map.get(key);
        return value != null ? value.toString() : null;
    }

    private static String extractDatabaseNameStatic(String url) {
        Pattern pattern = Pattern.compile("jdbc:mysql://[^/]+/([^?]+)");
        Matcher matcher = pattern.matcher(url);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    private static String extractProjectIdentifierStatic(String databaseName) {
        if (databaseName.contains("_")) {
            return databaseName.split("_")[0];
        }
        return databaseName;
    }

    /**
     * 解析YAML文件中的数据库配置
     */
    @SuppressWarnings("unchecked")
    private DatabaseConfig parseDbConfigFromYaml(File yamlFile) {
        try (FileInputStream fis = new FileInputStream(yamlFile)) {
            LoaderOptions loaderOptions = new LoaderOptions();
            loaderOptions.setMaxAliasesForCollections(50);
            loaderOptions.setAllowDuplicateKeys(false);

            Yaml yaml = new Yaml(new SafeConstructor(loaderOptions));
            Object yamlData = yaml.load(fis);

            if (yamlData instanceof Map) {
                Map<String, Object> data = (Map<String, Object>) yamlData;

                // 尝试获取 spring.datasource
                Object datasource = getNestedValue(data, "spring", "datasource");
                if (datasource == null) {
                    datasource = getNestedValue(data, "datasource");
                }

                if (datasource instanceof Map) {
                    Map<String, Object> dsMap = (Map<String, Object>) datasource;

                    DatabaseConfig config = new DatabaseConfig();
                    config.url = getStringValue(dsMap, "url");
                    config.username = getStringValue(dsMap, "username");
                    config.password = getStringValue(dsMap, "password");

                    if (config.url == null || config.username == null) {
                        return null;
                    }

                    // 从URL中提取数据库名
                    config.databaseName = extractDatabaseName(config.url);
                    if (config.databaseName == null) {
                        return null;
                    }

                    // 计算项目标识
                    config.projectIdentifier = extractProjectIdentifier(config.databaseName);

                    // 计算Flyway表名
                    config.flywayTableName = "flyway_schema_history_" + config.projectIdentifier;

                    System.out.println("[Flyway插件] 读取到数据库配置: " + config);
                    return config;
                }
            }
        } catch (Exception ex) {
            System.err.println("解析YAML配置失败: " + ex.getMessage());
        }
        return null;
    }

    /**
     * 安全获取嵌套Map的值
     */
    @SuppressWarnings("unchecked")
    private Object getNestedValue(Map<String, Object> map, String... keys) {
        Object current = map;
        for (String key : keys) {
            if (current instanceof Map) {
                current = ((Map<String, Object>) current).get(key);
            } else {
                return null;
            }
        }
        return current;
    }

    /**
     * 从Map中获取字符串值
     */
    private String getStringValue(Map<String, Object> map, String key) {
        Object value = map.get(key);
        return value != null ? value.toString() : null;
    }

    /**
     * 从JDBC URL中提取数据库名
     * 支持格式: jdbc:mysql://host:port/dbname?params
     */
    private String extractDatabaseName(String url) {
        // 匹配 jdbc:mysql://host:port/database 或 jdbc:mysql://host/database
        Pattern pattern = Pattern.compile("jdbc:mysql://[^/]+/([^?]+)");
        Matcher matcher = pattern.matcher(url);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    /**
     * 从数据库名提取项目标识
     * 规则：如果数据库名包含下划线，取第一部分
     */
    private String extractProjectIdentifier(String databaseName) {
        if (databaseName.contains("_")) {
            return databaseName.split("_")[0];
        }
        return databaseName;
    }

    /**
     * 获取本地SQL文件列表
     */
    private Map<String, File> getLocalSqlFiles() {
        Map<String, File> sqlFiles = new LinkedHashMap<>();

        for (String location : flywayLocations) {
            // 标准化路径
            String normalizedPath = location.replace("\\", "/").trim();
            if (normalizedPath.startsWith("/")) {
                normalizedPath = normalizedPath.substring(1);
            }

            // 在项目路径下查找
            File locationDir = new File(projectPath, normalizedPath);
            if (!locationDir.exists() || !locationDir.isDirectory()) {
                // 尝试在src/main/resources下查找
                locationDir = new File(projectPath, "src/main/resources/" + normalizedPath);
            }

            if (locationDir.exists() && locationDir.isDirectory()) {
                File[] files = locationDir.listFiles((dir, name) ->
                        name.toLowerCase().endsWith(".sql") && FLYWAY_VERSION_PATTERN.matcher(name).matches());
                if (files != null) {
                    for (File file : files) {
                        sqlFiles.put(file.getName(), file);
                    }
                }
            }
        }

        return sqlFiles;
    }

    /**
     * 获取数据库连接
     */
    private Connection getConnection(DatabaseConfig config) throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL驱动未找到: " + e.getMessage());
        }

        return DriverManager.getConnection(config.url, config.username, config.password);
    }

    /**
     * 检查表是否存在
     */
    private boolean tableExists(Connection conn, String tableName) throws SQLException {
        DatabaseMetaData meta = conn.getMetaData();
        try (ResultSet rs = meta.getTables(null, null, tableName, new String[]{"TABLE"})) {
            return rs.next();
        }
    }

    /**
     * 创建Flyway历史表
     */
    private void createFlywayTable(Connection conn, String tableName, String projectIdentifier) throws SQLException {
        String sql = "CREATE TABLE `" + tableName + "` (" +
                "`installed_rank` int NOT NULL, " +
                "`version` varchar(50) DEFAULT NULL, " +
                "`description` varchar(200) NOT NULL, " +
                "`type` varchar(20) NOT NULL, " +
                "`script` varchar(1000) NOT NULL, " +
                "`checksum` int DEFAULT NULL, " +
                "`installed_by` varchar(100) NOT NULL, " +
                "`installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, " +
                "`execution_time` int NOT NULL, " +
                "`success` tinyint(1) NOT NULL, " +
                "PRIMARY KEY (`installed_rank`), " +
                "KEY `" + tableName + "_s_idx` (`success`)" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci";

        try (Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(sql);
        }
    }

    /**
     * 获取Flyway历史记录
     */
    private List<FlywayHistoryRecord> getFlywayHistory(Connection conn, String tableName) throws SQLException {
        List<FlywayHistoryRecord> records = new ArrayList<>();

        String sql = "SELECT * FROM `" + tableName + "` ORDER BY installed_rank";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                FlywayHistoryRecord record = new FlywayHistoryRecord();
                record.installedRank = rs.getInt("installed_rank");
                record.version = rs.getString("version");
                record.description = rs.getString("description");
                record.type = rs.getString("type");
                record.script = rs.getString("script");
                record.checksum = rs.getObject("checksum") != null ? rs.getInt("checksum") : null;
                record.installedBy = rs.getString("installed_by");
                record.installedOn = rs.getTimestamp("installed_on");
                record.executionTime = rs.getInt("execution_time");
                record.success = rs.getBoolean("success");
                records.add(record);
            }
        }

        return records;
    }

    /**
     * 获取最大的installed_rank
     */
    private int getMaxInstalledRank(Connection conn, String tableName) throws SQLException {
        String sql = "SELECT COALESCE(MAX(installed_rank), 0) FROM `" + tableName + "`";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    /**
     * 更新success状态
     */
    private void updateSuccessStatus(Connection conn, String tableName, int installedRank, boolean success) throws SQLException {
        String sql = "UPDATE `" + tableName + "` SET success = ? WHERE installed_rank = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setBoolean(1, success);
            pstmt.setInt(2, installedRank);
            pstmt.executeUpdate();
        }
    }

    /**
     * 更新checksum
     */
    private void updateChecksum(Connection conn, String tableName, int installedRank, int checksum) throws SQLException {
        String sql = "UPDATE `" + tableName + "` SET checksum = ? WHERE installed_rank = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, checksum);
            pstmt.setInt(2, installedRank);
            pstmt.executeUpdate();
        }
    }

    /**
     * 删除历史记录
     */
    private void deleteHistoryRecord(Connection conn, String tableName, int installedRank) throws SQLException {
        String sql = "DELETE FROM `" + tableName + "` WHERE installed_rank = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, installedRank);
            pstmt.executeUpdate();
        }
    }

    /**
     * 插入历史记录
     */
    private void insertHistoryRecord(Connection conn, String tableName, int installedRank,
                                      String version, String description, String type,
                                      String script, int checksum, String installedBy,
                                      int executionTime, boolean success) throws SQLException {
        String sql = "INSERT INTO `" + tableName + "` " +
                "(installed_rank, version, description, type, script, checksum, installed_by, execution_time, success) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, installedRank);
            pstmt.setString(2, version);
            pstmt.setString(3, description);
            pstmt.setString(4, type);
            pstmt.setString(5, script);
            pstmt.setInt(6, checksum);
            pstmt.setString(7, installedBy);
            pstmt.setInt(8, executionTime);
            pstmt.setBoolean(9, success);
            pstmt.executeUpdate();
        }
    }

    /**
     * 执行SQL文件
     */
    private void executeSqlFile(Connection conn, File sqlFile) throws SQLException {
        try {
            String sqlContent = new String(Files.readAllBytes(sqlFile.toPath()), StandardCharsets.UTF_8);

            // 分割SQL语句（按分号分割，但要注意字符串中的分号）
            List<String> statements = splitSqlStatements(sqlContent);

            conn.setAutoCommit(false);
            try (Statement stmt = conn.createStatement()) {
                for (String sql : statements) {
                    String trimmedSql = sql.trim();
                    if (!trimmedSql.isEmpty() && !trimmedSql.startsWith("--") && !trimmedSql.startsWith("/*")) {
                        stmt.execute(trimmedSql);
                    }
                }
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (IOException e) {
            throw new SQLException("读取SQL文件失败: " + e.getMessage());
        }
    }

    /**
     * 分割SQL语句
     */
    private List<String> splitSqlStatements(String sqlContent) {
        List<String> statements = new ArrayList<>();
        StringBuilder currentStatement = new StringBuilder();
        boolean inString = false;
        char stringChar = 0;

        for (int i = 0; i < sqlContent.length(); i++) {
            char c = sqlContent.charAt(i);

            // 处理字符串
            if ((c == '\'' || c == '"') && (i == 0 || sqlContent.charAt(i - 1) != '\\')) {
                if (!inString) {
                    inString = true;
                    stringChar = c;
                } else if (c == stringChar) {
                    inString = false;
                }
            }

            // 分号分割（不在字符串内）
            if (c == ';' && !inString) {
                String stmt = currentStatement.toString().trim();
                if (!stmt.isEmpty()) {
                    statements.add(stmt);
                }
                currentStatement = new StringBuilder();
            } else {
                currentStatement.append(c);
            }
        }

        // 最后一条语句
        String lastStmt = currentStatement.toString().trim();
        if (!lastStmt.isEmpty()) {
            statements.add(lastStmt);
        }

        return statements;
    }

    /**
     * 计算Flyway checksum（与Flyway 5.2.4官方一致）
     * Flyway 5.2.4 checksum计算方式：
     * - 逐行读取文件内容（BufferedReader.readLine()）
     * - 每行内容转为UTF-8字节后更新CRC32
     * - 不添加换行符
     */
    private int calculateFlywayChecksum(File file) {
        try {
            CRC32 crc32 = new CRC32();
            
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
                
                String line;
                boolean firstLine = true;
                
                while ((line = reader.readLine()) != null) {
                    // 移除第一行的BOM（如果有）
                    if (firstLine && line.length() > 0 && line.charAt(0) == '\uFEFF') {
                        line = line.substring(1);
                    }
                    firstLine = false;
                    
                    // 每行内容转为UTF-8字节后更新CRC32（不加换行符）
                    crc32.update(line.getBytes(StandardCharsets.UTF_8));
                }
            }
            
            return (int) crc32.getValue();
        } catch (IOException e) {
            System.err.println("计算checksum失败: " + file.getName() + " - " + e.getMessage());
            return 0;
        }
    }

    /**
     * 从文件名提取版本号
     * V1.2.3__desc.sql -> 1.2.3
     */
    private String extractVersionFromFileName(String fileName) {
        Matcher matcher = FLYWAY_VERSION_PATTERN.matcher(fileName);
        if (matcher.matches()) {
            return matcher.group(1).replace("_", ".");
        }
        return "0";
    }

    /**
     * 从文件名提取描述
     * V1.2.3__create_table.sql -> create_table
     */
    private String extractDescriptionFromFileName(String fileName) {
        int startIndex = fileName.indexOf("__");
        if (startIndex >= 0) {
            String desc = fileName.substring(startIndex + 2);
            if (desc.toLowerCase().endsWith(".sql")) {
                desc = desc.substring(0, desc.length() - 4);
            }
            return desc.replace("_", " ");
        }
        return fileName;
    }

    /**
     * 从文件名提取类型
     */
    private String extractTypeFromFileName(String fileName) {
        char firstChar = Character.toUpperCase(fileName.charAt(0));
        switch (firstChar) {
            case 'V':
                return "SQL";
            case 'U':
                return "UNDO_SQL";
            case 'R':
                return "SQL_REPEATABLE";
            default:
                return "SQL";
        }
    }

    /**
     * 比较两个Flyway版本号
     */
    private int compareFlywayVersion(String file1, String file2) {
        int[] v1 = extractVersionArray(file1);
        int[] v2 = extractVersionArray(file2);

        int maxLen = Math.max(v1.length, v2.length);
        for (int i = 0; i < maxLen; i++) {
            int num1 = i < v1.length ? v1[i] : 0;
            int num2 = i < v2.length ? v2[i] : 0;
            if (num1 != num2) {
                return Integer.compare(num1, num2);
            }
        }
        return 0;
    }

    /**
     * 从文件名提取版本号数组
     */
    private int[] extractVersionArray(String fileName) {
        Matcher matcher = FLYWAY_VERSION_PATTERN.matcher(fileName);
        if (matcher.matches()) {
            String versionStr = matcher.group(1);
            String[] parts = versionStr.split("[._]");
            int[] version = new int[parts.length];
            for (int i = 0; i < parts.length; i++) {
                try {
                    version[i] = Integer.parseInt(parts[i]);
                } catch (NumberFormatException e) {
                    version[i] = 0;
                }
            }
            return version;
        }
        return new int[]{0};
    }

    /**
     * 检查是否存在版本号重复的SQL文件
     * @param sqlFileNames SQL文件名集合
     * @return 版本号重复的映射 (版本号 -> 文件名列表)，如果没有重复则返回空 Map
     */
    private Map<String, List<String>> checkDuplicateVersions(Set<String> sqlFileNames) {
        // 按版本号分组文件
        Map<String, List<String>> versionToFiles = new LinkedHashMap<>();
        
        for (String fileName : sqlFileNames) {
            String version = extractVersionFromFileName(fileName);
            versionToFiles.computeIfAbsent(version, k -> new ArrayList<>()).add(fileName);
        }
        
        // 筛选出有重复的版本
        Map<String, List<String>> duplicates = new LinkedHashMap<>();
        for (Map.Entry<String, List<String>> entry : versionToFiles.entrySet()) {
            if (entry.getValue().size() > 1) {
                duplicates.put(entry.getKey(), entry.getValue());
            }
        }
        
        return duplicates;
    }
}
