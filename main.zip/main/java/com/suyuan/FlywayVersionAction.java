package com.suyuan;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.CommonDataKeys;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.progress.Task;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.ListBranchCommand;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevTree;
import org.eclipse.jgit.revwalk.RevWalk;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.eclipse.jgit.treewalk.TreeWalk;
import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.SafeConstructor;

import java.io.*;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Flyway SQL版本分析插件的核心入口类
 * 功能：获取项目中所有近一个月有提交的分支下的Flyway SQL最大版本号
 * @author zhangx
 */
public class FlywayVersionAction extends AnAction {

    // Flyway SQL文件名匹配模式: V1.0.0__description.sql 或 V1_0_0__description.sql
    private static final Pattern FLYWAY_VERSION_PATTERN = Pattern.compile(
            "^[VvUuRr]([0-9]+(?:[._][0-9]+)*)__.*\\.sql$"
    );

    /**
     * 分支扫描结果封装类
     */
    private static class BranchScanResult {
        boolean isGitRepo = false;
        String errorMsg = null;
        List<String> recentBranches = new ArrayList<>();
        Map<String, String> allBranches = new LinkedHashMap<>(); // 分支名 -> 最新提交时间
        int localBranchCount = 0;
        int remoteBranchCount = 0;
    }

    /**
     * 分析结果封装类，用于传递给对话框
     */
    private static class AnalysisResult {
        String message;                              // 分析结果消息
        List<String> flywayLocations;               // Flyway locations配置
        Set<String> allSqlFiles;                    // 所有SQL文件（去重后）
        Map<String, Set<String>> branchSqlFiles;   // 各分支SQL文件映射
        boolean hasSqlFiles;                        // 是否找到SQL文件
    }

    @Override
    public void actionPerformed(AnActionEvent e) {
        Project project = e.getData(CommonDataKeys.PROJECT);
        if (project == null) {
            Messages.showErrorDialog("未检测到当前项目，请打开项目后重试！", "错误");
            return;
        }

        String projectPath = project.getBasePath();
        if (projectPath == null) {
            Messages.showErrorDialog(project, "无法获取项目路径！", "错误");
            return;
        }

        // 询问用户选择操作
        int choice = Messages.showYesNoCancelDialog(
                project,
                "请选择要执行的操作：\n\n" +
                        "• 【获取最大SQL版本】分析当前项目各分支的Flyway SQL文件，获取最大版本号\n" +
                        "• 【一键修复】检测并修复Flyway版本历史记录表问题\n" +
                        "• 【取消】取消操作",
                "Flyway SQL版本分析",
                "获取最大SQL版本",
                "一键修复",
                "取消",
                Messages.getQuestionIcon()
        );

        if (choice == Messages.CANCEL) {
            return; // 用户取消
        }

        // 如果用户选择一键修复（NO按钮）
        if (choice == Messages.NO) {
            executeRepairDirectly(project, projectPath);
            return;
        }

        // 用户选择获取最大SQL版本（YES按钮）

        // 使用后台任务执行，避免阻塞UI
        ProgressManager.getInstance().run(new Task.Backgroundable(project, "Flyway SQL版本分析", true) {
            @Override
            public void run(ProgressIndicator indicator) {
                try {
                    indicator.setText("正在读取Flyway配置...");
                    List<String> flywayLocations = readFlywayLocationsFromYaml(projectPath);
                    if (flywayLocations.isEmpty()) {
                        showResult(project, "未找到Flyway locations配置！\n\n请检查 application.yml 中的 spring.flyway.locations 或 flyway.locations 配置");
                        return;
                    }

                    indicator.setText("正在获取Git分支信息...");
                    BranchScanResult branchResult = getRecentBranches(projectPath, 30);

                    // 检查Git状态
                    if (!branchResult.isGitRepo) {
                        showResult(project, "当前项目不是Git仓库！\n\n请确保项目已初始化Git。");
                        return;
                    }

                    if (branchResult.errorMsg != null) {
                        showResult(project, "获取Git分支失败！\n\n" + branchResult.errorMsg);
                        return;
                    }

                    List<String> recentBranches = branchResult.recentBranches;
                    if (recentBranches.isEmpty()) {
                        StringBuilder msg = new StringBuilder();
                        msg.append("未找到近一个月有提交记录的分支！\n\n");
                        msg.append("【Git仓库状态】\n");
                        msg.append("  • 本地分支数: ").append(branchResult.localBranchCount).append("\n");
                        msg.append("  • 远程分支数: ").append(branchResult.remoteBranchCount).append("\n");

                        if (branchResult.remoteBranchCount == 0 && branchResult.localBranchCount > 0) {
                            msg.append("\n【可能的原因】\n");
                            msg.append("  • 未执行 git fetch 同步远程分支\n");
                            msg.append("  • Git未登录或认证失败\n");
                            msg.append("\n【建议】\n");
                            msg.append("  请先执行: git fetch --all\n");
                        }

                        if (!branchResult.allBranches.isEmpty()) {
                            msg.append("\n【所有分支及最新提交时间】\n");
                            int count = 0;
                            for (Map.Entry<String, String> entry : branchResult.allBranches.entrySet()) {
                                if (count++ < 10) {
                                    msg.append("  • ").append(entry.getKey())
                                            .append(" (").append(entry.getValue()).append(")\n");
                                }
                            }
                            if (branchResult.allBranches.size() > 10) {
                                msg.append("  ... 还有 ").append(branchResult.allBranches.size() - 10).append(" 个分支\n");
                            }
                        }

                        showResult(project, msg.toString());
                        return;
                    }

                    indicator.setText("正在扫描各分支的SQL文件...");
                    Map<String, Set<String>> branchSqlFiles = new LinkedHashMap<>();
                    Map<String, Set<String>> branchAllSqlFiles = new LinkedHashMap<>(); // 所有SQL文件（包括不符合命名规范的）
                    Set<String> allSqlFiles = new TreeSet<>();
                    Set<String> allSqlFilesRaw = new TreeSet<>(); // 原始文件名
                    Map<String, String> fileToBranchMap = new HashMap<>(); // SQL文件名 -> 分支名映射

                    for (int i = 0; i < recentBranches.size(); i++) {
                        String branch = recentBranches.get(i);
                        indicator.setFraction((double) i / recentBranches.size());
                        indicator.setText2("分支: " + branch);

                        Set<String>[] result = getSqlFilesFromBranch(projectPath, branch, flywayLocations);
                        Set<String> sqlFiles = result[0]; // Flyway规范文件
                        Set<String> rawSqlFiles = result[1]; // 所有SQL文件

                        if (!rawSqlFiles.isEmpty()) {
                            branchAllSqlFiles.put(branch, rawSqlFiles);
                            allSqlFilesRaw.addAll(rawSqlFiles);
                        }
                        if (!sqlFiles.isEmpty()) {
                            branchSqlFiles.put(branch, sqlFiles);
                            allSqlFiles.addAll(sqlFiles);
                            // 记录每个SQL文件来自哪个分支
                            for (String sqlFile : sqlFiles) {
                                // 如果文件名相同但来自不同分支，记录第一个遇到的分支
                                if (!fileToBranchMap.containsKey(sqlFile)) {
                                    fileToBranchMap.put(sqlFile, branch);
                                }
                            }
                        }
                    }

                    if (allSqlFiles.isEmpty()) {
                        StringBuilder diagMsg = new StringBuilder();
                        diagMsg.append("在所有分支中未找到符合Flyway命名规范的SQL文件！\n\n");
                        diagMsg.append("【Flyway目录配置】\n");
                        for (String loc : flywayLocations) {
                            diagMsg.append("  • ").append(loc).append("\n");
                        }
                        diagMsg.append("\n【扫描到的分支数】 ").append(recentBranches.size()).append("个\n");

                        if (!allSqlFilesRaw.isEmpty()) {
                            diagMsg.append("\n【找到的SQL文件（不符合Flyway命名规范）】\n");
                            int count = 0;
                            for (String f : allSqlFilesRaw) {
                                if (count++ < 10) {
                                    diagMsg.append("  • ").append(f).append("\n");
                                }
                            }
                            if (allSqlFilesRaw.size() > 10) {
                                diagMsg.append("  ... 还有 ").append(allSqlFilesRaw.size() - 10).append(" 个文件\n");
                            }
                            diagMsg.append("\n【Flyway命名规范】\n");
                            diagMsg.append("  V{version}__{description}.sql\n");
                            diagMsg.append("  例如: V1.0.0__create_table.sql\n");
                            diagMsg.append("  例如: V1_0_0__init.sql\n");
                        } else {
                            diagMsg.append("\n【诺断】 在指定目录下未找到任何.sql文件");
                        }

                        showResult(project, diagMsg.toString());
                        return;
                    }

                    // 按版本号排序，获取最大版本
                    indicator.setText("正在分析版本号...");
                    String maxVersionFile = findMaxVersionSqlFile(allSqlFiles);

                    // 获取最大版本SQL文件所在的分支
                    String maxVersionFileBranch = fileToBranchMap.get(maxVersionFile);
                    if (maxVersionFileBranch == null) {
                        maxVersionFileBranch = "未知分支";
                    }

                    // 构建结果
                    StringBuilder result = new StringBuilder();
                    result.append("═══ Flyway SQL版本分析结果 ═══\n\n");
                    result.append("【最大版本SQL文件】\n");
                    result.append("  ").append(maxVersionFile).append("\n");
                    result.append("  来自分支: ").append(maxVersionFileBranch).append("\n\n");
                    result.append("【Flyway配置目录】\n");
                    for (String loc : flywayLocations) {
                        result.append("  • ").append(loc).append("\n");
                    }
                    result.append("\n【去重SQL文件总数】 ").append(allSqlFiles.size()).append("个");

                    // 使用普通对话框显示结果（不包含一键修复按钮）
                    showResult(project, result.toString());

                } catch (Exception ex) {
                    showError(project, "插件执行失败：" + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        });
    }

    /**
     * 从 application.yml 中读取 Flyway locations 配置
     * 支持 spring.flyway.locations 和 flyway.locations 两种配置方式
     */
    private List<String> readFlywayLocationsFromYaml(String projectPath) {
        List<String> locations = new ArrayList<>();
        List<String> searchedPaths = new ArrayList<>();

        // 收集所有可能的YAML文件路径
        List<String> yamlPaths = new ArrayList<>();

        // 标准路径（优先级从高到低）
        String[] standardPaths = {
                // 项目根目录下的配置文件（优先）
                "/application.yml",
                "/application.yaml",
                "/application-dev.yml",
                "/application-dev.yaml",
                "/application-prod.yml",
                "/application-local.yml",
                // 标准 Spring Boot 路径
                "/src/main/resources/application.yml",
                "/src/main/resources/application.yaml",
                "/src/main/resources/application-dev.yml",
                "/src/main/resources/application-dev.yaml",
                "/src/main/resources/application-prod.yml",
                "/src/main/resources/application-local.yml"
        };

        // 添加项目根目录下的标准路径
        for (String path : standardPaths) {
            yamlPaths.add(projectPath + path);
        }

        // 递归查找子模块中的配置文件
        findYamlFilesInSubmodules(new File(projectPath), yamlPaths, 3);

        for (String yamlPath : yamlPaths) {
            File yamlFile = new File(yamlPath);
            searchedPaths.add(yamlPath);
            if (yamlFile.exists() && yamlFile.isFile()) {
                List<String> found = parseFlywayLocations(yamlFile);
                if (!found.isEmpty()) {
                    locations.addAll(found);
                    System.out.println("[Flyway插件] 从配置文件读取到locations: " + found + " (文件: " + yamlPath + ")");
                    break; // 找到就停止
                }
            }
        }

        // 如果没找到配置，使用Flyway默认目录
        if (locations.isEmpty()) {
            locations.add("db/migration");
            System.out.println("[Flyway插件] 未找到flyway.locations配置，使用默认值: db/migration");
            System.out.println("[Flyway插件] 已搜索的路径: " + searchedPaths.size() + "个");
        }

        // 处理classpath:和filesystem:前缀
        return locations.stream()
                .map(this::normalizeLocation)
                .collect(Collectors.toList());
    }

    /**
     * 递归查找子模块中的YAML配置文件
     */
    private void findYamlFilesInSubmodules(File dir, List<String> yamlPaths, int maxDepth) {
        if (maxDepth <= 0 || dir == null || !dir.isDirectory()) {
            return;
        }

        File[] subDirs = dir.listFiles(File::isDirectory);
        if (subDirs == null) return;

        for (File subDir : subDirs) {
            // 跳过隐藏目录和常见的非源码目录
            String name = subDir.getName();
            if (name.startsWith(".") || name.equals("target") || name.equals("build")
                    || name.equals("node_modules") || name.equals("out")) {
                continue;
            }

            // 检查是否是Maven/Gradle模块（有pom.xml或build.gradle）
            boolean isModule = new File(subDir, "pom.xml").exists()
                    || new File(subDir, "build.gradle").exists()
                    || new File(subDir, "build.gradle.kts").exists();

            if (isModule) {
                // 添加该模块的配置文件路径
                String modulePath = subDir.getAbsolutePath();
                yamlPaths.add(modulePath + "/src/main/resources/application.yml");
                yamlPaths.add(modulePath + "/src/main/resources/application.yaml");
                yamlPaths.add(modulePath + "/src/main/resources/application-dev.yml");
                yamlPaths.add(modulePath + "/src/main/resources/application-prod.yml");
            }

            // 继续递归查找
            findYamlFilesInSubmodules(subDir, yamlPaths, maxDepth - 1);
        }
    }

    /**
     * 解析YAML文件中的Flyway locations配置
     */
    @SuppressWarnings("unchecked")
    private List<String> parseFlywayLocations(File yamlFile) {
        List<String> locations = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(yamlFile)) {
            LoaderOptions loaderOptions = new LoaderOptions();
            loaderOptions.setMaxAliasesForCollections(50);
            loaderOptions.setAllowDuplicateKeys(false);

            Yaml yaml = new Yaml(new SafeConstructor(loaderOptions));
            Object yamlData = yaml.load(fis);

            if (yamlData instanceof Map) {
                Map<String, Object> data = (Map<String, Object>) yamlData;

                // 尝试 spring.flyway.locations
                Object locationsObj = getNestedValue(data, "spring", "flyway", "locations");
                if (locationsObj == null) {
                    // 尝试 flyway.locations
                    locationsObj = getNestedValue(data, "flyway", "locations");
                }

                if (locationsObj != null) {
                    if (locationsObj instanceof List) {
                        for (Object item : (List<?>) locationsObj) {
                            if (item != null) {
                                locations.add(item.toString());
                            }
                        }
                    } else if (locationsObj instanceof String) {
                        // 可能是逗号分隔的字符串
                        String[] parts = ((String) locationsObj).split(",");
                        for (String part : parts) {
                            locations.add(part.trim());
                        }
                    }
                }
            }
        } catch (Exception ex) {
            System.err.println("无法读取YAML文件: " + ex.getMessage());
        }

        return locations;
    }

    /**
     * 安全获取嵌套Map的值
     */
    @SuppressWarnings("unchecked")
    private Object getNestedValue(Map<String, Object> map, String... keys) {
        Object current = map;
        for (String key : keys) {
            if (current instanceof Map) {
                current = ((Map<String, Object>) current).get(key);
            } else {
                return null;
            }
        }
        return current;
    }

    /**
     * 标准化location路径，移除classpath:等前缀
     */
    private String normalizeLocation(String location) {
        if (location.startsWith("classpath:")) {
            return location.substring("classpath:".length());
        } else if (location.startsWith("filesystem:")) {
            return location.substring("filesystem:".length());
        }
        return location;
    }

    /**
     * 获取近N天有提交记录的所有分支（去重）
     */
    private BranchScanResult getRecentBranches(String projectPath, int days) {
        BranchScanResult result = new BranchScanResult();
        Set<String> recentBranches = new LinkedHashSet<>();
        Instant cutoffTime = Instant.now().minus(days, ChronoUnit.DAYS);

        java.time.format.DateTimeFormatter formatter = java.time.format.DateTimeFormatter
                .ofPattern("yyyy-MM-dd HH:mm")
                .withZone(java.time.ZoneId.systemDefault());

        File gitDir = new File(projectPath, ".git");
        if (!gitDir.exists()) {
            result.isGitRepo = false;
            return result;
        }
        result.isGitRepo = true;

        try (Git git = Git.open(new File(projectPath))) {
            Repository repository = git.getRepository();

            // 获取所有远程分支
            List<Ref> remoteBranches = git.branchList()
                    .setListMode(ListBranchCommand.ListMode.REMOTE)
                    .call();
            result.remoteBranchCount = remoteBranches.size();

            for (Ref branch : remoteBranches) {
                try {
                    // 过滤掉 HEAD 符号引用（不是真正的分支）
                    if (branch.getName().endsWith("/HEAD") || branch.isSymbolic()) {
                        continue;
                    }

                    ObjectId objectId = branch.getObjectId();
                    if (objectId == null) continue;

                    try (RevWalk revWalk = new RevWalk(repository)) {
                        RevCommit commit = revWalk.parseCommit(objectId);
                        Instant commitTime = Instant.ofEpochSecond(commit.getCommitTime());

                        String branchName = branch.getName();
                        if (branchName.startsWith("refs/remotes/origin/")) {
                            branchName = branchName.substring("refs/remotes/origin/".length());
                        } else if (branchName.startsWith("refs/remotes/")) {
                            branchName = branchName.substring("refs/remotes/".length());
                        }

                        // 记录所有分支信息
                        result.allBranches.put(branchName, formatter.format(commitTime));

                        if (commitTime.isAfter(cutoffTime)) {
                            recentBranches.add(branchName);
                        }
                    }
                } catch (Exception ex) {
                    System.err.println("无法获取分支信息: " + branch.getName() + " - " + ex.getMessage());
                }
            }

            // 获取本地分支
            List<Ref> localBranches = git.branchList().call();
            result.localBranchCount = localBranches.size();

            for (Ref branch : localBranches) {
                try {
                    // 过滤掉 HEAD 符号引用
                    if (branch.getName().endsWith("/HEAD") || branch.isSymbolic()) {
                        continue;
                    }

                    ObjectId objectId = branch.getObjectId();
                    if (objectId == null) continue;

                    try (RevWalk revWalk = new RevWalk(repository)) {
                        RevCommit commit = revWalk.parseCommit(objectId);
                        Instant commitTime = Instant.ofEpochSecond(commit.getCommitTime());

                        String branchName = branch.getName();
                        if (branchName.startsWith("refs/heads/")) {
                            branchName = branchName.substring("refs/heads/".length());
                        }

                        // 记录本地分支信息（如果远程没有同名分支）
                        if (!result.allBranches.containsKey(branchName)) {
                            result.allBranches.put(branchName + " (本地)", formatter.format(commitTime));
                        }

                        if (commitTime.isAfter(cutoffTime)) {
                            recentBranches.add(branchName);
                        }
                    }
                } catch (Exception ex) {
                    System.err.println("无法获取本地分支信息: " + branch.getName() + " - " + ex.getMessage());
                }
            }

        } catch (Exception ex) {
            result.errorMsg = ex.getMessage();
            System.err.println("无法获取Git分支列表: " + ex.getMessage());
        }

        result.recentBranches = new ArrayList<>(recentBranches);
        return result;
    }

    /**
     * 从指定分支获取Flyway SQL文件列表
     * @return 数组[0]为符合Flyway规范的文件, [1]为所有SQL文件
     */
    @SuppressWarnings("unchecked")
    private Set<String>[] getSqlFilesFromBranch(String projectPath, String branchName, List<String> flywayLocations) {
        Set<String> sqlFiles = new TreeSet<>();
        Set<String> allSqlFiles = new TreeSet<>();

        try (Git git = Git.open(new File(projectPath))) {
            Repository repository = git.getRepository();

            // 尝试获取分支引用
            ObjectId branchId = repository.resolve("refs/remotes/origin/" + branchName);
            if (branchId == null) {
                branchId = repository.resolve("refs/heads/" + branchName);
            }
            if (branchId == null) {
                branchId = repository.resolve(branchName);
            }

            if (branchId == null) {
                return new Set[]{sqlFiles, allSqlFiles};
            }

            try (RevWalk revWalk = new RevWalk(repository)) {
                RevCommit commit = revWalk.parseCommit(branchId);
                RevTree tree = commit.getTree();

                // 遍历每个 Flyway location 目录
                for (String location : flywayLocations) {
                    try (TreeWalk treeWalk = new TreeWalk(repository)) {
                        treeWalk.addTree(tree);
                        treeWalk.setRecursive(true);

                        // 标准化路径：移除前后空格和多余的斜杠
                        String normalizedPath = location.replace("\\", "/").trim();
                        // 移除开头的斜杠
                        if (normalizedPath.startsWith("/")) {
                            normalizedPath = normalizedPath.substring(1);
                        }
                        // 移除末尾的斜杠
                        if (normalizedPath.endsWith("/")) {
                            normalizedPath = normalizedPath.substring(0, normalizedPath.length() - 1);
                        }

                        while (treeWalk.next()) {
                            String filePath = treeWalk.getPathString();

                            // 检查文件是否在指定目录下且是.sql文件
                            // 支持多种匹配方式：
                            // 1. 路径以目标目录开头: docker/app/scripts/db-migration/xxx.sql
                            // 2. 路径包含目标目录: some/path/docker/app/scripts/db-migration/xxx.sql
                            // 3. 目录名匹配（路径的最后一个目录名）
                            boolean inTargetDir = false;

                            // 方式1：完全路径匹配
                            if (filePath.startsWith(normalizedPath + "/")) {
                                inTargetDir = true;
                            }
                            // 方式2：作为子路径匹配
                            else if (filePath.contains("/" + normalizedPath + "/")) {
                                inTargetDir = true;
                            }
                            // 方式3：只匹配最后一个目录名（如果配置的是短路径，如 db-migration）
                            else {
                                String lastDir = normalizedPath;
                                if (normalizedPath.contains("/")) {
                                    lastDir = normalizedPath.substring(normalizedPath.lastIndexOf("/") + 1);
                                }
                                // 检查文件的父目录是否匹配
                                int lastSlash = filePath.lastIndexOf("/");
                                if (lastSlash > 0) {
                                    String parentPath = filePath.substring(0, lastSlash);
                                    if (parentPath.endsWith("/" + lastDir) || parentPath.equals(lastDir)
                                            || parentPath.endsWith(normalizedPath)) {
                                        inTargetDir = true;
                                    }
                                }
                            }

                            if (inTargetDir && filePath.toLowerCase().endsWith(".sql")) {
                                String fileName = filePath.substring(filePath.lastIndexOf("/") + 1);
                                allSqlFiles.add(fileName); // 所有SQL文件

                                // 只添加符合Flyway命名规范的文件（V/U/R开头）
                                if (FLYWAY_VERSION_PATTERN.matcher(fileName).matches()) {
                                    sqlFiles.add(fileName);
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception ex) {
            System.err.println("无法获取分支 [" + branchName + "] 的SQL文件: " + ex.getMessage());
        }

        return new Set[]{sqlFiles, allSqlFiles};
    }

    /**
     * 查找版本号最大的SQL文件
     */
    private String findMaxVersionSqlFile(Set<String> sqlFiles) {
        return sqlFiles.stream()
                .filter(f -> FLYWAY_VERSION_PATTERN.matcher(f).matches())
                .max((f1, f2) -> compareFlywayVersion(f1, f2))
                .orElse("未找到");
    }

    /**
     * 比较两个Flyway SQL文件的版本号
     */
    private int compareFlywayVersion(String file1, String file2) {
        int[] v1 = extractVersion(file1);
        int[] v2 = extractVersion(file2);

        int maxLen = Math.max(v1.length, v2.length);
        for (int i = 0; i < maxLen; i++) {
            int num1 = i < v1.length ? v1[i] : 0;
            int num2 = i < v2.length ? v2[i] : 0;
            if (num1 != num2) {
                return Integer.compare(num1, num2);
            }
        }
        return 0;
    }

    /**
     * 从文件名提取版本号数组
     * 例如: V1.2.3__desc.sql -> [1, 2, 3]
     * 例如: V1_2_3__desc.sql -> [1, 2, 3]
     */
    private int[] extractVersion(String fileName) {
        Matcher matcher = FLYWAY_VERSION_PATTERN.matcher(fileName);
        if (matcher.matches()) {
            String versionStr = matcher.group(1);
            // 统一分隔符，支持 . 和 _ 两种格式
            String[] parts = versionStr.split("[._]");
            int[] version = new int[parts.length];
            for (int i = 0; i < parts.length; i++) {
                try {
                    version[i] = Integer.parseInt(parts[i]);
                } catch (NumberFormatException e) {
                    version[i] = 0;
                }
            }
            return version;
        }
        return new int[]{0};
    }

    /**
     * 在EDT线程上显示结果弹窗
     */
    private void showResult(Project project, String message) {
        ApplicationManager.getApplication().invokeLater(() ->
                Messages.showMessageDialog(project, message, "Flyway SQL版本分析结果", Messages.getInformationIcon())
        );
    }

    /**
     * 直接执行一键修复操作
     */
    private void executeRepairDirectly(Project project, String projectPath) {
        // 读取Flyway配置
        List<String> flywayLocations = readFlywayLocationsFromYaml(projectPath);
        if (flywayLocations.isEmpty()) {
            Messages.showErrorDialog(project, "未找到Flyway locations配置！\n\n请检查 application.yml 中的 spring.flyway.locations 或 flyway.locations 配置", "错误");
            return;
        }

        // 自动检测配置文件路径
        String detectedConfigPath = FlywayRepairService.detectConfigFilePath(projectPath);
        String configInfo = detectedConfigPath != null 
            ? "自动检测到配置文件: " + detectedConfigPath
            : "未检测到配置文件，请手动选择";

        // 显示修复结果对话框
        FlywayAnalysisResultDialog dialog = new FlywayAnalysisResultDialog(
                project,
                projectPath,
                "═══ Flyway一键修复 ═══\n\n" +
                        "【Flyway配置目录】\n" +
                        flywayLocations.stream().map(loc -> "  • " + loc).collect(Collectors.joining("\n")) +
                        "\n\n" + configInfo +
                        "\n\n请确认上方配置后，点击“开始修复”按钮...",
                flywayLocations,
                new TreeSet<String>(),  // 空的SQL文件集合，修复服务会自己获取
                new LinkedHashMap<String, Set<String>>(),
                true  // hasSqlFiles = true，启用修复按钮
        );
        dialog.show();
    }

    /**
     * 在EDT线程上显示错误弹窗
     */
    private void showError(Project project, String message) {
        ApplicationManager.getApplication().invokeLater(() ->
                Messages.showErrorDialog(project, message, "错误")
        );
    }

    /**
     * 执行 git fetch --all 同步远程分支
     * @return null表示成功，否则返回错误信息
     */
    private String executeGitFetch(String projectPath) {
        try (Git git = Git.open(new File(projectPath))) {
            System.out.println("[Flyway插件] 开始执行 git fetch --all...");
            // 执行 fetch 操作
            git.fetch()
                    .setRemote("origin")
                    .setRefSpecs("+refs/heads/*:refs/remotes/origin/*")
                    //.setCredentialsProvider(new UsernamePasswordCredentialsProvider(username, password))
                    .call();

            System.out.println("[Flyway插件] git fetch 完成");
            return null; // 成功
        } catch (Exception ex) {
            String errorMsg = ex.getMessage();
            System.err.println("[Flyway插件] git fetch 失败: " + errorMsg);
            return errorMsg;
        }
    }

    /**
     * 获取Git凭据的辅助方法
     */
    private GitCredentials getGitCredentials(Project project) {
        GitCredentialsDialog dialog = new GitCredentialsDialog(project);
        if (dialog.showAndGet()) {
            return new GitCredentials(
                    dialog.getUsername(),
                    dialog.getPassword()
            );
        }
        return null; // 用户取消
    }

    /**
     * 凭据数据类
     */
    private static class GitCredentials {
        private final String username;
        private final String password;

        public GitCredentials(String username, String password) {
            this.username = username;
            this.password = password;
        }

        public String getUsername() { return username; }
        public String getPassword() { return password; }
    }

    /**
     * 执行 git fetch --all 同步远程分支
     * @return null表示成功，否则返回错误信息
     */
    private String executeGitFetch(String projectPath, Project project) {
        // 在EDT线程中获取凭据
        GitCredentials[] credentialsHolder = new GitCredentials[1];
        boolean[] userCancelled = new boolean[1];

        // 在EDT线程中显示对话框
        ApplicationManager.getApplication().invokeAndWait(() -> {
            GitCredentials credentials = getGitCredentials(project);
            if (credentials != null) {
                credentialsHolder[0] = credentials;
            } else {
                userCancelled[0] = true;
            }
        });

        // 如果用户取消，则返回
        if (userCancelled[0]) {
            return "用户取消认证";
        }

        GitCredentials credentials = credentialsHolder[0];

        try (Git git = Git.open(new File(projectPath))) {
            System.out.println("[Flyway插件] 开始执行 git fetch --all...");

            git.fetch()
                    .setRemote("origin")
                    .setRefSpecs("+refs/heads/*:refs/remotes/origin/*")
                    .setCredentialsProvider(new UsernamePasswordCredentialsProvider(
                            credentials.getUsername(),
                            credentials.getPassword()
                    ))
                    .call();

            System.out.println("[Flyway插件] git fetch 完成");
            return null; // 成功
        } catch (Exception ex) {
            String errorMsg = ex.getMessage();
            System.err.println("[Flyway插件] git fetch 失败: " + errorMsg);
            return errorMsg;
        }
    }



    /**
     * 控制插件菜单的显示条件（仅在有项目时显示）
     */
    @Override
    public void update(AnActionEvent e) {
        Project project = e.getData(CommonDataKeys.PROJECT);
        e.getPresentation().setEnabledAndVisible(project != null);
    }
}